# AeroMesh ResQ

**A drone-deployed temporary emergency communication network using LoRa-based wireless mesh technology.**

AeroMesh ResQ is a concept and prototype project intended to support emergency messaging when conventional mobile communication infrastructure is unavailable or disrupted during disasters.

## Project overview

Drones are proposed to carry and deploy portable beacon nodes in affected areas. The beacon nodes form a multi-hop LoRa mesh network. A nearby victim's mobile phone connects to a beacon through a local Wi-Fi access point and can submit an SOS message and location details. Messages are relayed through the mesh to a gateway and displayed at a rescue-team dashboard.

> **Important communication distinction:** LoRa is used for communication between beacon nodes. Wi-Fi provides the local phone-to-beacon connection. An ESP32 Wi-Fi access point does not itself provide internet or cellular service. The current prototype scope is local emergency messaging and location sharing, not ordinary cellular calls or full mobile broadband.

## System architecture

![AeroMesh ResQ block diagram](images/AeroMesh_ResQ_Block_Diagram.jpeg)

### Main system layers

1. **Drone deployment:** carries and deploys portable beacon nodes.
2. **Beacon nodes:** ESP32, LoRa transceiver, antenna and power supply.
3. **LoRa mesh:** relays emergency packets between available nodes using multi-hop forwarding.
4. **Mobile access:** a beacon's Wi-Fi access point provides a local connection for nearby phones.
5. **Gateway and dashboard:** receives relayed messages and presents SOS alerts and location information to responders.

## Miniature working prototype

![AeroMesh ResQ miniature working prototype](images/AeroMesh_ResQ_Miniature_Working_Prototype.jpeg)

The photograph above is the miniature hardware setup supplied with the project document. Refer to the project report for the exact component list, wiring, firmware status and test results.

## Repository structure

```text
AeroMesh-ResQ/
├── README.md
├── images/
│   ├── AeroMesh_ResQ_Block_Diagram.jpeg
│   └── AeroMesh_ResQ_Miniature_Working_Prototype.jpeg
└── docs/
    └── AeroMesh_ResQ_Original_Document.docx
```

## Current development status

This repository currently contains the supplied block diagram, miniature prototype photograph and original project document. Add the verified firmware, circuit/wiring diagram, component list, test procedure and measured results as they become available. Do not describe untested functions as completed.

## Suggested future validation

- Verify phone-to-beacon Wi-Fi connection and SOS submission.
- Verify LoRa packet transmission and reception between nodes.
- Demonstrate multi-hop forwarding across more than one relay node.
- Measure packet delivery ratio, end-to-end delay and communication range.
- Verify gateway reception and dashboard alert display.
- Test battery runtime and recovery after a node failure.

## Project note

This is a prototype/research development repository. Drone deployment, multi-hop routing, gateway integration and dashboard functions should be marked as implemented only after they have been demonstrated and tested.
